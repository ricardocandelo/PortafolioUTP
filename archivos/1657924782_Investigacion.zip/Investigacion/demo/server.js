const { response } = require('express');
const express = require('express');
const multiparty = require('multiparty');

const app = express();
const PORT=5000;
const IMAGE_UPLOAD_DIR ="./public/images";

  // Middleware
app.use(express.static(public));

  //router 
app.get('/', (req, res) => {
    console.log("Home...")
    res.send("home.page")

  });

app.post('/add.product-form', (req, res) => {
    let form = new multiparty.Form({uploadDir: IMAGE_UPLOAD_DIR})

    form.parse(req, function (err, fields, files) {
        if (err) response.send ({erro : err.message});
    
        console.log(`fields:  ${JSON.stringify(fields, null, 2)}`)
        console.log(`files:  ${JSON.stringify(fields, null, 2)}`)
    
    });

  });

  //Server Rum
  app.listen(PORT, () => {
    console.log(`Server running at : http:localhost:${PORT}`);
  })